const express= require("express");
const app = express();
app.get("/",(req,res)=> res.send("hello from app5"));
app.listen(8000, () => console.log("app 5 is running"));