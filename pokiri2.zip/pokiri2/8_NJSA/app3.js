const express= require("express");
const app = express();
app.get("/",(req,res)=> res.send("hello from app3"));
app.listen(6000, () => console.log("app 3 is running"));