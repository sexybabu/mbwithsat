const express= require("express");
const app = express();
app.get("/",(req,res)=> res.send("hello from app1"));
app.listen(3000, () => console.log("app 1 is running"));