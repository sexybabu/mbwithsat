const express= require("express");
const app = express();
app.get("/",(req,res)=> res.send("hello from app2"));
app.listen(5000, () => console.log("app 2 is running"));