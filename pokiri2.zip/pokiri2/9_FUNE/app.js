const express=require("express");
const bodyparser=require("body-parser");
const app=express();
const port =3000;
app.use(bodyparser.urlencoded({extended:true}));
app.use(express.static("public"));
app.get("/",(req,res)=>{
    res.sendFile(__dirname+"/index.html");
});
app.post("/register",(req,res)=>{
    const formdata=req.body;
    console.log(formdata);
    res.send(`<h1>thank you for submitting</h1>
        <p><strong>Name :</strong>${formdata.name}</p>
        <p><strong>email :</strong>${formdata.email}</p>
        <p><strong>phone :</strong>${formdata.phone}</p>
        <p><strong>DOB :</strong>${formdata.dob}</p>
        <p><strong>gender :</strong>${formdata.gender}</p>
        <p><strong>exam :</strong>${formdata.exam}</p>
        <p><strong>doe :</strong>${formdata.doe}</p>
        <p><strong>Address :</strong>${formdata.address}</p>
        <a href="/">go back to registraion</a>

        `);
});


app.listen(port,()=>{
    console.log(`server is running on port ${port}`);
});
